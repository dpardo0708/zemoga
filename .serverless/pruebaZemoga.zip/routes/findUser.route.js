const Twitter = require('twitter');
const serverless = require('serverless-http');
const express = require('express');
const bodyParser= require('body-parser')

const app = express();

app.use(bodyParser.urlencoded({ extended: true }))

app.use(bodyParser.json())

const findUserController = require("../controllers/findUser.controller")
const findUserTimeLine = require("../controllers/findUser.controller")
 
const client = new Twitter({
  consumer_key: process.env.CONSUMER_KEY,
  consumer_secret: process.env.CONSUMER_SECRET,
  access_token_key: process.env.ACCESS_TOKEN_KEY,
  access_token_secret: process.env.ACCESS_TOKEN_SECRET
});

const params = {q: 'dmpmonte'};
app.get('/user', (req, res) => {
  client.get('users/search.json', params, findUserController)
  client.get('statuses/user_timeline',findUserTimeLine )
})

module.exports.handler = serverless(app)